# Ausplayer

Ausplayer is a page developed to facilitate exchanges and chats among popular online game players, covering most of today's mainstream online games. Players can use the posting function to ask questions and chat here, and they can also leave messages to customer service in the chat box of the website.

# Develop Environment

Python 3.11.3 


# Functions realized by the web page:

 1. Registration and login function. Users can register an account by themselves. During the registration process, they need to enter their email address, and then the web page verifies the email address by sending a verification code to the email address. After the verification is correct, the registration is successful, and then they can log in with the account password.

2. Chat function. The software has two chat functions. The first is the chat box. On the homepage, click the game option on the homepage to enter the chat box under the game, and you can send real-time messages. The main chatting function of this webpage is blog chatting function, different users can send posts and replies to each other to promote game-related communication. 

3. History and search history function. The background of the website stores the history of all posts and replies, and using the search bar in the history area, you can also filter out the search results you want.



# requirements:

aiohttp==3.8.4
aiosignal==1.3.1
aniso8601==9.0.1
async-generator==1.10
async-timeout==4.0.2
attrs==23.1.0
autopep8==2.0.2
certifi==2022.12.7
charset-normalizer==3.1.0
click==8.1.3
exceptiongroup==1.1.1
Flask==2.2.3
Flask-Login==0.6.2
Flask-SQLAlchemy==3.0.3
frozenlist==1.3.3
greenlet==2.0.2
h11==0.14.0
idna==3.4
importlib-metadata==6.6.0
itsdangerous==2.1.2
Jinja2==3.1.2
MarkupSafe==2.1.2
multidict==6.0.4
openai==0.27.4
outcome==1.2.0
packaging==23.1
pycodestyle==2.10.0
PySocks==1.7.1
python-dotenv==1.0.0
pytz==2023.3
requests==2.28.2
selenium==4.9.0
six==1.16.0
sniffio==1.3.0
sortedcontainers==2.4.0
SQLAlchemy==2.0.12
tomli==2.0.1
tqdm==4.65.0
trio==0.22.0
trio-websocket==0.10.2
typing-extensions==4.5.0
urllib3==1.26.15
webdriver-manager==3.8.6
Werkzeug==2.2.3
wsproto==1.2.0
yarl==1.9.2
zipp==3.15.0