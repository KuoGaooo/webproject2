import unittest
from app.utils import uuid


class TestUtils(unittest.TestCase):
    def test_gen_uuid(self):
        self.assertIsNotNone(uuid.gen_uuid())
        self.assertTrue(len(uuid.gen_uuid()) == 36)
